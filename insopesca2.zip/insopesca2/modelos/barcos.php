<?php

    require_once "conexion.php";


    class ModeloBarco {

         /*=============================================
	    MOSTRAR USUARIOS
	    =============================================*/

	    static public function mdlMostrarBarco($tabla, $item, $valor){
        
	    	if($item != null){
            
	    		$stmt = Conexion::conectar()->prepare("SELECT * FROM $tabla WHERE $item = :$item");
            
	    		$stmt -> bindParam(":".$item, $valor, PDO::PARAM_STR);
            
	    		$stmt -> execute();
            
	    		return $stmt -> fetch();
            
	    	}else{
            
	    		$stmt = Conexion::conectar()->prepare("SELECT * FROM $tabla");
            
	    		$stmt -> execute();
            
	    		return $stmt -> fetchAll();
            
	    	}
        
        
	    	$stmt -> close();
        
	    	$stmt = null;
        
	    }

		static public function mdlMostrarBarcoyPersona($valor){
        
	    	
	    		$stmt = Conexion::conectar()->prepare('- '.$valor);
            				
	    		$stmt -> execute();
            
	    		return $stmt -> fetch();
            
        
	    		$stmt -> close();
        
	    		$stmt = null;
        
	    }

		/*=============================================
		REGISTRO DE USUARIO
		=============================================*/

		static public function mdlIngresarBarco($tabla, $datos){

			$stmt = Conexion::conectar()->prepare("INSERT INTO $tabla(id_persona, nombre_barco, eslora, manga, puntal, comppa, uab, especies, arte_pesca) VALUES (:id_persona, :nombre_barco, :eslora, :manga, :puntal, :comppa, :uab, :especies, :arte_pesca)");
			
			$stmt->bindParam(":id_persona", $datos["id_persona"], PDO::PARAM_INT);
			$stmt->bindParam(":nombre_barco", $datos["nombre_barco"], PDO::PARAM_STR);
			$stmt->bindParam(":eslora", $datos["eslora"], PDO::PARAM_INT);
			$stmt->bindParam(":manga", $datos["manga"], PDO::PARAM_INT);
			$stmt->bindParam(":puntal", $datos["puntal"], PDO::PARAM_INT);
			$stmt->bindParam(":comppa", $datos["comppa"], PDO::PARAM_STR);
			$stmt->bindParam(":uab", $datos["uab"], PDO::PARAM_STR);
			$stmt->bindParam(":especies", $datos["especies"], PDO::PARAM_STR);
			$stmt->bindParam(":arte_pesca", $datos["arte_pesca"], PDO::PARAM_STR);
			

			if($stmt->execute()){

				return "ok";	

			}else{

				return "error";
			
			}

			$stmt->close();

			$stmt = null;

		}

		/*=============================================
		EDITAR  USUARIO
		=============================================*/

		static public function mdlEditarBarco($tabla, $datos){

			$stmt = Conexion::conectar()->prepare("UPDATE $tabla SET nombre_barco = :nombre_barco, eslora = :eslora, manga = :manga, puntal = :puntal, comppa = :comppa, uab = :uab, especies = :especies, arte_pesca = :arte_pesca WHERE id = :id");
			
			$stmt->bindParam(":nombre_barco", $datos["nombre_barco"], PDO::PARAM_STR);
			$stmt->bindParam(":eslora", $datos["eslora"], PDO::PARAM_INT);
			$stmt->bindParam(":manga", $datos["manga"], PDO::PARAM_INT);
			$stmt->bindParam(":puntal", $datos["puntal"], PDO::PARAM_INT);
			$stmt->bindParam(":comppa", $datos["comppa"], PDO::PARAM_STR);
			$stmt->bindParam(":uab", $datos["uab"], PDO::PARAM_STR);
			$stmt->bindParam(":especies", $datos["especies"], PDO::PARAM_STR);
			$stmt->bindParam(":arte_pesca", $datos["arte_pesca"], PDO::PARAM_STR);
			$stmt -> bindParam(":id", $datos["id"], PDO::PARAM_INT);

			if($stmt->execute()){

				return "ok";	

			}else{

				return "error";
			
			}

			$stmt->close();

			$stmt = null;

		}

		/*=============================================
		BORRAR USUARIO
		=============================================*/

	static public function mdlBorrarBarco($tabla, $datos){

		$stmt = Conexion::conectar()->prepare("DELETE FROM $tabla WHERE id = ".$datos);
		

		if($stmt -> execute()){

			return "ok";
		
		}else{

			return "error";	

		}

		$stmt -> close();

		$stmt = null;


	}

    }

?>