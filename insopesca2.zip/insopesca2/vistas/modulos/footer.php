<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-left">
            <p>2024 &copy; INSOPESCA</p>
        </div>
        <div class="float-right">
            <p>Hecho con <span class='text-danger'><i data-feather="heart"></i></span> por <a href="#">MOONCAT</a></p>
        </div>
    </div>
</footer>