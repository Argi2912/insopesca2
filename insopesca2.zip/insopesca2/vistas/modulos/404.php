<div id="error">
        
        <div class="container text-center pt-32">
            <h1 class='error-title'>404</h1>
            <p>No pudimos encontrar la pagina solicitada</p>
            <a href="index.html" class='btn btn-primary'>Ir al Inicio</a>
        </div>
        
                <div class="footer pt-32">
                    <p class="text-center">Copyright &copy;</p>
                </div>
            </div>