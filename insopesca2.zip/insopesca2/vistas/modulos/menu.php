    <div id="sidebar" class="active">
            <div class="sidebar-wrapper active">
                <div class="sidebar-header">
                    <h3><b>INSOPESCA</b></h3>
                </div>
                <div class="sidebar-menu">
                    <ul class="menu">
            
                        <li class='sidebar-title'>Menu Principal</li>
            
                        <li class="sidebar-item  ">
                            <a href="inicio" class='sidebar-link'>
                                <i data-feather="home" width="20"></i> 
                             <span>Inicio</span>
                            </a>
                    
                        </li>
                        <li class="sidebar-item  ">
                            <a href="usuarios" class="sidebar-link">
                                <i data-feather="user" width="20"></i> 
                                <span>Usuarios</span>
                            </a>
                        
                        </li>
                        <li class="sidebar-item  ">
                            <a href="personas" class="sidebar-link">
                                <i data-feather="user" width="20"></i> 
                                <span>Personas</span>
                            </a>
                        
                        </li>
                        <li class="sidebar-item  ">
                            <a href="barcos" class="sidebar-link">
                                <i data-feather="user" width="20"></i> 
                                <span>Barcos</span>
                            </a>
                        
                        </li>
                        <!-- <li class="sidebar-item  has-sub">
                            <a href="#" class='sidebar-link'>
                                <i data-feather="file-text" width="20"></i> 
                                <span>Permisos</span>
                            </a>
                            <ul class="submenu ">
                                <li>
                                    <a href="permisos">Solicitudes de Permisos</a>
                                </li>
                                <li>
                                    <a href="crear-permisos">Solicitar Permisos</a>
                                </li>
                            </ul>
                        </li> -->

                     
                        
                    </ul>
                </div>
            <button class="sidebar-toggler btn x"><i data-feather="x"></i></button>
    </div>